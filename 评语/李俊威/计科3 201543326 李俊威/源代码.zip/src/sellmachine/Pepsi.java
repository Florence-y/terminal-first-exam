package sellmachine;

public class Pepsi extends Drink{
    public void Data(){
        drinkName="Pepsi";
        drinkPrice=2;
        drinkVolume=350;
    }
    public void advertisement(){
        System.out.println("广告语:可口可乐是最难喝的饮料！");
    }
}
