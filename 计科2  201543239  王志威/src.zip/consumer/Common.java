package consumer;

/**
 * 普通消费者
 * @author WEIR
 *
 */
public class Common extends Person{

/**
 * 获取折扣
 */
	public double getDiscount() {
		return 9.8;
	}
}