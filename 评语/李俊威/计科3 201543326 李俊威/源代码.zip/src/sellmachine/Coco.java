package sellmachine;

public class Coco extends Drink{
    public void Data(){
        drinkName="Coco";
        drinkPrice=2;
        drinkVolume=350;
    }
    public void advertisement(){
        System.out.println("广告语:比百事好喝的可乐！");
    }
}
