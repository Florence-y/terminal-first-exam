package sellmachine;

public abstract class Drink
{
    public String drinkName;
    public int drinkVolume;
    public int drinkPrice;
    public abstract void advertisement();
    public abstract void Data();
}
