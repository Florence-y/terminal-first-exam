package vendingmachine;

/**
 * 可口可乐
 */
public class Coco extends Drink implements canDrink
{
/**
 * 打印可口可乐的广告
 */
	public void printf() {
		System .out.println("广告语：可口可乐，清凉一夏！");
	}
}
