package main;


/**
 * 选项
 * @author WEIR
 *
 */
public class Option{
	
/**
 * 展示选项
 */
	public void show() {
		System .out.println("---------------------");
		System .out.println("[1] 显示饮料机");
		System .out.println("[2] 充值ֵ");
		System .out.println("[3] 购买用户喜欢的饮料");
		System .out.println("[4] 通知老板填充货架");
		System .out.println("[5] 切换用户");
		System .out.println("[6] 设置用户喜欢的饮料");
		System .out.println("[7] 购买指定货架的饮料");
		System .out.println("[8] 退出");
		System .out.println("---------------------");
		System .out.print("请输入命令：");
	}
}


