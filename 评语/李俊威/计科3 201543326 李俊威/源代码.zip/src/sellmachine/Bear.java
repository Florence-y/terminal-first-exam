package sellmachine;

public class Bear extends Drink{
    public void Data(){
        drinkName="Bear";
        drinkPrice=3;
        drinkVolume=450;
    }
    public void advertisement(){
        System.out.println("广告语:我有酒,你有故事吗？");
    }
}
