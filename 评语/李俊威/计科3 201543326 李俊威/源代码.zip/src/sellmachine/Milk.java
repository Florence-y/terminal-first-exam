package sellmachine;

public class Milk extends Drink{
    public void Data(){
        drinkName="Milk";
        drinkPrice=3;
        drinkVolume=450;
    }
    public void advertisement(){
        System.out.println("广告语:每天一杯少不了,身体棒棒天天好！");
    }
}
