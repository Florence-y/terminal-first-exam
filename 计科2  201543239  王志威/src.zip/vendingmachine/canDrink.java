package vendingmachine;

/**
  可饮用接口
 */
public interface canDrink {

/**
 打印广告的接口
 */
	public  void printf() ;
			
}
