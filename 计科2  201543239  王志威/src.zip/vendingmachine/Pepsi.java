package vendingmachine;

/**
  百事可乐
 */
public class Pepsi extends Drink implements canDrink
{
/**
 * 打印百事可乐的广告
 */
	public void printf() {
		System .out.println("广告语：百事可乐，打败可口！");
	}
}